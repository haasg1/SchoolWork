// Java program for different tree traversals 
  
/* Class containing left and right child of current 
   node and key value*/
class node { 
	
	int data;
    String key; 
    node left, right; 
  
    
    public node(String string, int item) 
    { 
    	data = item;
        key = string; 
        left = right = null; 
    } 
} 
  
class Res { 
    public int val; 
} 

class BinaryTree { 
    // Root of Binary Tree 
    node root; 
    
    
    //calculates path cost 
    int findMaxUtil(node node, Res res) 
    { 
  
        // Base Case 
        if (node == null) 
            return 0; 
 
        int l = findMaxUtil(node.left, res); 
        int r = findMaxUtil(node.right, res); 
  
        // Max path for parent call of root. This path must 
        // include at-most one child of root 
        int max_single = Math.max(Math.max(l, r) + node.data, 
                                  node.data); 
  
        int max_top = Math.max(max_single, l + r + node.data); 
  
        // Store the Maximum Result. 
        res.val = Math.max(res.val, max_top); 
  
        return max_single; 
    } 
  
    int findMaxSum() { 
        return findMaxSum(root); 
    } 
  
    // Returns maximum path sum in tree with given root 
    int findMaxSum(node node) { 
  
        // Initialize result 
        // int res2 = Integer.MIN_VALUE; 
        Res res = new Res(); 
        res.val = Integer.MIN_VALUE; 
  
        // Compute and return result 
        findMaxUtil(node, res); 
        return res.val; 
    } 
  
    
    BinaryTree() 
    { 
        root = null; 
    } 
  
    void printDFS(node node) 
    { 
        if (node == null) 
            return; 
  
        /* first print data of node */
        System.out.print(node.key + " "); 
  
        /* then recur on left sutree */
        printDFS(node.left); 
  
        /* now recur on right subtree */
        printDFS(node.right); 
    } 
  
    // Wrappers over above recursive functions 
    void printDFS() { printDFS(root); } 
  
    // Driver method 
    public static void main(String[] args) 
    { 
        BinaryTree tree = new BinaryTree(); 
        tree.root = new node("A", 1); 
        tree.root.left = new node("B", 1);
        tree.root.left.left = new node("D", 1);
        tree.root.left.left.left = new node("H", 1);
        tree.root.left.right = new node("E", 1);
        tree.root.right = new node("C", 1);
        tree.root.right.left = new node("F", 1);
        tree.root.right.right = new node("G", 1);
        
       
        System.out.println("Depth First traversal of binary tree is "); 
        tree.printDFS(); 
        System.out.println();
        System.out.println("Total Path Cost: " + 
                tree.findMaxSum()); 
        
    } 
    
} 