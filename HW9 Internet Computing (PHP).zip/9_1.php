<?php
// reading variables values
$res = $_GET['Res'];
$name = $_GET['name'];
$mail = $_GET['email'];
$phone = $_GET['phone'];
$rating = $_GET['rating'];
$comment = $_GET['comments'];
echo "Thank you, ".$res." ".$name.", for your comments<br>";
echo "Your email address is ".$mail." and your phone number is ".$phone."<br>";
echo "You stated that you found this example to be '".$rating."'and added:<br>";
echo $comment;
?>