<?php

$price = $_POST['price'];  
$qty = $_POST['qty'];  
$discount = $_POST['discount'];
$tax = $_POST['tax'];
$tax = $tax/100;
$shipping_method = $_POST['shipping_method'];
$payment = $_POST['payment'];

if ($shipping_method == "Slow_and_Steady")
{
$shipping_method = 5;
}
elseif ($shipping_method == "Put_a_move")
{
$shipping_method = 6;
}
else
{
$shipping_method = 7;
}

$total = ($qty * $price) - $discount + $shipping_method ;
$total_tax = $tax * $total;
$total_amount = $total + $total_tax ;
$installment = $total_amount / $payment ;

echo "Fill out the form to calculate the total cost: <br>";
echo $qty. " widget(s) at <br>";
echo "$".$price." each plus a <br>";
echo "$".$shipping_method." shipping cost and a <br>";
echo $tax." percent tax rate \n";
echo "after your ".$discount."% discount, the total cost is ".$total_amount.".<br>";
echo "Divided over ".$payment." monthly payments, that would be ".$installment." each.";


?>