<?php

$server = 'localhost';
$user = 'User';
$password = 'pass';
$db = 'csit101';

$connection = mysql_connect($server, $user, $password)

or die ("Could not connect to server ... \n" . mysql_error ());

mysql_select_db($db)

or die ("Could not connect to database ... \n" . mysql_error ());

$myConnection= mysqli_connect("$server","$user","$password") or die ("could not connect to mysql"); 

mysqli_select_db($myConnection, "efurnish") or die ("no database"); 





?>