<?php

session_start();

include_once("connection.php");


$email = isset($_POST['email']) ? $_POST['email'] : '';
if (isset($_POST['submit'])) { 
$email=$_POST["email"];
}


$password = isset($_POST['password']) ? $_POST['password'] : '';
if (isset($_POST['submit'])) { 
$password=$_POST["password"];
}

$sqllogin="select * from administrators where email = '.$email.', and password = '.$password.';"

$reclogin=mysql_query($sqllogin) or die(mysql_error());

$numlogin=mysql_num_rows($reclogin);

if($numlogin)

{

$rowlogin=mysql_fetch_array($reclogin);

$_SESSION["mpdc_loginid"]=$rowlogin["id"];

$_SESSION["mpdc_loginuserid"]=$rowlogin["userid"];

header("Location:main.php?$success");

}

else

{

header("Location:index.php?$error");

}

?>