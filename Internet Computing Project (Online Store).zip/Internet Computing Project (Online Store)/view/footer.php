
<footer>
    <p id="copyright">
        &copy; <?php echo date("Y"); ?> EFurnish, Inc.
    </p>
</footer>
</body>
</html>