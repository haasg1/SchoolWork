<!DOCTYPE html>
<html>

<!-- the head section -->
<head>
    <link rel="stylesheet" type="text/css"
          href="<?php echo $app_path ?>main.css">
   <title>E-Furnish</title>
   <h1 style = "font-family:Goudy Stout;"><center>E-Furnish</center></h1>
<style>
   body {
   background-color: #DBA901;
   }

ul {
   list-style-type: none;
   margin: 0;
   padding: 0;
   overflow: hidden;
   background-color: #B43104;
}

li  {
   float: left;
}

li a {
   display: block;
   color: white;
   text-align: center;
   padding: 14px 16px;
   text-decoration: none;
}

li a:hover {
   background-color: #111;
}


</style>
</head>

</html>

