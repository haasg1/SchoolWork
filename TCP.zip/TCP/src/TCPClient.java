//TCPClient.java

import java.net.*;

import java.io.*;

import java.util.*;

public class TCPClient {

    private static final int PORT = 5000;

    private static final String HOSTNAME = "localhost";

    public static void main(String[] args) {

        try {

Socket socket = null;

            try {

                socket = new Socket(HOSTNAME, PORT);

            } catch (UnknownHostException e) {

                e.printStackTrace();

            }

            System.out.println("Connected.");

            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            DataInputStream in = new DataInputStream(socket.getInputStream());

            Scanner scanner = new Scanner(System.in);

            // added the while loop for serving multiple request

            while (true) {

                String line = scanner.nextLine();

                // if user quit then cleaning the resources and exiting the program

                if (line.equals("Quit")) {

                    scanner.close();

                    out.close();

                    in.close();

                    socket.close();

                    break;

                }

                out.writeUTF(line);

                out.flush();

                String response = in.readUTF();

                System.out.println(response);

            }

        } catch (IOException e) {

            e.printStackTrace();

        }

    }

}