// ***************************************************************
// StackTest.java
//
// A simple driver to test a stack.
//
// ***************************************************************
import java.util.Stack;
public class StackTest
{
public static void main(String[] args)
{
// Declare and instantiate a stack
Stack stack = new Stack();
//push some stuff on the stack
for (int i=0; i<10; i++)
stack.push(i);
stack.push(5);
// call printStack to print the stack
// call reverseStack to reverse the stack
// call printStack to print the stack again
// call removeElement to remove all occurrences of the value 5 - save the
// stack returned from this call
// call printStack to print the original stack and the new stack.
}
}