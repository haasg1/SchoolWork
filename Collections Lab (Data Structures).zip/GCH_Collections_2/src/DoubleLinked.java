// ***************************************************************
// DoubleLinked.java
//
// A class using a doubly linked list to represent a list of integers.
//
// ***************************************************************
public class DoubleLinked
{
private IntNode list;
// ----------------------------------------------
// Constructor -- initializes list
// ----------------------------------------------
public DoubleLinked()
{
list = null;
}
// ----------------------------------------------
// Prints the list elements
// ----------------------------------------------
public void print()
{
for (IntNode temp = list; temp != null; temp = temp.next)
 System.out.println(temp.val);
}
// ----------------------------------------------
// Adds new element to front of list
// ----------------------------------------------
public void addToFront(int val)
{
IntNode newNode = new IntNode(val);
newNode.next = list;
if (list != null)
 list.prev = newNode;
list = newNode;
} 
//***************************************************************
//An inner class that represents a list element.
//***************************************************************
private class IntNode
{
public int val;
public IntNode next;
public IntNode prev;
public IntNode(int val)
{
this.val = val;
this.next = null;
this.prev = null;
}
}
} 