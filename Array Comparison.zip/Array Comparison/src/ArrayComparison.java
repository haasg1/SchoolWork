public class ArrayComparison {

    public static void main(String[] args) {
      
   //for loop to fill arrays
   		int[] array1 =new int[200000];
   		for (int i=0;i <100000;++i){
   			array1[i]=i;
   			
   		int [] array2=new int[200000];
   		for (int j=0;j <200000;++j){
   			array2[j]=i;
   			}
   }
      
        int count=0;
      
        long start = System.currentTimeMillis();
        int [] array2=new int[200000];
        //the nested for loop to compare the elements
        for(int i = 0; i < 200000; i++) {
            for(int j = 0; j < 200000; j++) {
					if((array1[i] == array2[j])) {
                        count++;                    
                }
            }
        }
      
        long end = System.currentTimeMillis();
        long totalTime = end - start;
        System.out.println("Running time= "+totalTime+ " msec");
    }
  

}