import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.border.MatteBorder;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.border.EtchedBorder;

public class MadLibss extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	DateFormat dformat = new SimpleDateFormat("MM/dd/y HH:mm");		//Code for the date; will change every day to that day's date.
	Date date = new Date();											//
		
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MadLibss frame = new MadLibss();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MadLibss() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 495, 455);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(148, 0, 211));
		contentPane.setBorder(new EtchedBorder(EtchedBorder.RAISED, new Color(255, 255, 255), new Color(192, 192, 192)));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblMadLibs = new JLabel("MAD LIBS!");
		lblMadLibs.setForeground(new Color(255, 255, 255));
		lblMadLibs.setFont(new Font("Centaur", Font.BOLD, 30));
		lblMadLibs.setBounds(149, 13, 187, 43);
		contentPane.add(lblMadLibs);
		
		JLabel lblPleaseEnterA = new JLabel("Please enter a name.");
		lblPleaseEnterA.setForeground(new Color(255, 255, 255));
		lblPleaseEnterA.setBounds(12, 67, 131, 16);
		contentPane.add(lblPleaseEnterA);
		
		JLabel lblPleaseEnterA_1 = new JLabel("Enter Make/Model of a car: ");
		lblPleaseEnterA_1.setForeground(new Color(255, 255, 255));
		lblPleaseEnterA_1.setBounds(12, 96, 187, 16);
		contentPane.add(lblPleaseEnterA_1);
		
		JLabel lblPleaseEnterA_2 = new JLabel("Enter A Bone: ");
		lblPleaseEnterA_2.setForeground(new Color(255, 255, 255));
		lblPleaseEnterA_2.setBounds(12, 123, 146, 16);
		contentPane.add(lblPleaseEnterA_2);
		
		JLabel lblPleaseEnterA_3 = new JLabel("Enter A Time: ");
		lblPleaseEnterA_3.setForeground(new Color(255, 255, 255));
		lblPleaseEnterA_3.setBounds(12, 154, 338, 16);
		contentPane.add(lblPleaseEnterA_3);
		
		JLabel lblPleaseEnterA_4 = new JLabel("Enter A Color:");
		lblPleaseEnterA_4.setForeground(new Color(255, 255, 255));
		lblPleaseEnterA_4.setBounds(12, 183, 197, 16);
		contentPane.add(lblPleaseEnterA_4);
		
		textField = new JTextField();
		textField.setBounds(349, 64, 116, 22);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(349, 93, 116, 22);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(349, 122, 116, 22);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(349, 151, 116, 22);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(349, 180, 116, 22);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnMadLibIt = new JButton("CLICK ME!");
		btnMadLibIt.setForeground(new Color(148, 0, 211));
		btnMadLibIt.setBackground(Color.GRAY);
		btnMadLibIt.setFont(new Font("Centaur", Font.BOLD, 20));
		
		btnMadLibIt.setBounds(149, 317, 187, 78);
		contentPane.add(btnMadLibIt);
		
		final JTextPane textPane = new JTextPane();
		textPane.setFont(new Font("Centaur", Font.BOLD, 18));
		textPane.setForeground(new Color(255, 255, 255));
		textPane.setBackground(new Color(139, 0, 139));
		textPane.setBounds(12, 25, 453, 346);
		contentPane.add(textPane);
		
		JLabel lblNewLabel = new JLabel("Date & Time: " + dformat.format(date));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(0, 0, 279, 16);
		contentPane.add(lblNewLabel);
		textPane.setVisible(false);
		
		btnMadLibIt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textPane.setVisible(true);
				textPane.setVisible(true);					//Below is my entire story. 
				textPane.setText("Dear Mr Johnson, \nIt is I, " + textField.getText() + "."
				+ "Unfortunately, I crashed my  " + textField_1.getText() + "."
				+ "I think I fractured my " + textField_2.getText() + "bone"
				+ " I have a doctor's appointement at " + textField_3.getText() + "." 
				+ " I will be taking a " + textField_4.getText() + " taxi to get to the doctor's office." 
				+ "\nSincerely, \nThe Best Employee Ever!"); 
				
			}
		});
		
	}
}